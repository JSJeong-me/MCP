"""초급자용 FastMCP 클라이언트 예제.

실행하면 다음 순서로 동작합니다.
1. server.py를 자식 프로세스로 자동 실행
2. MCP 서버 연결 확인
3. Tool / Resource / Prompt 목록 조회
4. Tool 호출
5. Resource 읽기
6. Prompt 가져오기
7. 연결 종료와 함께 서버 프로세스 종료
"""

from __future__ import annotations

import asyncio
import json
import sys
from pathlib import Path
from typing import Any

from fastmcp import Client
from fastmcp.client.transports import StdioTransport


BASE_DIR = Path(__file__).resolve().parent
SERVER_FILE = BASE_DIR / "server.py"


def print_title(text: str) -> None:
    """출력 구역을 보기 쉽게 구분합니다."""
    print("\n" + "=" * 70)
    print(text)
    print("=" * 70)


def pretty(value: Any) -> str:
    """dict/list를 읽기 쉬운 JSON 형태로 출력합니다."""
    if isinstance(value, (dict, list)):
        return json.dumps(value, ensure_ascii=False, indent=2, default=str)
    return str(value)


async def main() -> None:
    # 현재 client.py를 실행한 Python을 그대로 사용해 server.py를 실행합니다.
    # 따라서 가상환경 안에서 `python client.py`를 실행하면 서버도 같은
    # 가상환경의 FastMCP 패키지를 사용합니다.
    transport = StdioTransport(
        command=sys.executable,
        args=[str(SERVER_FILE)],
        cwd=str(BASE_DIR),
    )

    client = Client(transport)

    print_title("0. FastMCP 클라이언트 시작")
    print(f"클라이언트 Python: {sys.executable}")
    print(f"실행할 서버 파일: {SERVER_FILE}")

    try:
        # async with 블록에 들어가면 서버 프로세스가 시작되고 MCP 연결이 열립니다.
        async with client:
            print_title("1. 서버 연결 확인")
            await client.ping()
            print("서버가 정상적으로 응답했습니다.")

            print_title("2. 서버가 제공하는 구성요소 목록")

            tools = await client.list_tools()
            print("[Tools]")
            for tool in tools:
                print(f"- {tool.name}: {tool.description or '설명 없음'}")

            resources = await client.list_resources()
            print("\n[Resources]")
            for resource in resources:
                print(f"- {resource.uri}: {resource.description or resource.name}")

            prompts = await client.list_prompts()
            print("\n[Prompts]")
            for prompt in prompts:
                print(f"- {prompt.name}: {prompt.description or '설명 없음'}")

            print_title("3. Tool 호출: add")
            add_result = await client.call_tool("add", {"a": 7, "b": 5})
            print(f"7 + 5 = {pretty(add_result.data)}")

            print_title("4. Tool 호출: greet")
            greet_result = await client.call_tool("greet", {"name": "MCP 학습자"})
            print(pretty(greet_result.data))

            print_title("5. Tool 호출: add_note")
            note_result = await client.call_tool(
                "add_note",
                {
                    "title": "FastMCP 첫 실습",
                    "content": "WSL에서 stdio 방식으로 client와 server를 연결했다.",
                },
            )
            print("저장된 메모:")
            print(pretty(note_result.data))

            print_title("6. Tool 호출: search_notes")
            search_result = await client.call_tool(
                "search_notes",
                {"keyword": "stdio"},
            )
            print("검색 결과:")
            print(pretty(search_result.data))

            print_title("7. Resource 읽기: notes://all")
            resource_contents = await client.read_resource("notes://all")
            for item in resource_contents:
                if hasattr(item, "text"):
                    print(item.text)
                elif hasattr(item, "blob"):
                    print(f"바이너리 데이터 {len(item.blob)} bytes")

            print_title("8. Prompt 가져오기: study_review")
            prompt_result = await client.get_prompt(
                "study_review",
                {"topic": "MCP Server와 Client"},
            )
            for index, message in enumerate(prompt_result.messages, start=1):
                content = (
                    message.content.text
                    if hasattr(message.content, "text")
                    else message.content
                )
                print(f"메시지 {index} / role={message.role}")
                print(content)

        # async with 블록을 벗어나면 연결과 서버 프로세스가 정리됩니다.
        print_title("9. 실습 완료")
        print("MCP 연결이 종료되었고 서버 프로세스도 정리되었습니다.")

    except FileNotFoundError:
        print("오류: server.py 또는 Python 실행 파일을 찾지 못했습니다.")
        raise SystemExit(1)
    except Exception as exc:
        print_title("실행 중 오류 발생")
        print(f"오류 종류: {type(exc).__name__}")
        print(f"오류 내용: {exc}")
        print("가상환경 활성화와 FastMCP 설치 여부를 확인하세요.")
        raise SystemExit(1) from exc


if __name__ == "__main__":
    asyncio.run(main())
