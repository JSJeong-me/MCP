# Windows WSL FastMCP Client & Server 초급 실습

이 예제는 WSL Ubuntu에서 로컬 MCP 서버와 클라이언트가 `stdio` 방식으로
연결되는 과정을 학습하기 위한 프로젝트입니다.

## 1. 프로젝트 구조

```text
fastmcp_wsl_beginner/
├── server.py          # Tool, Resource, Prompt를 제공하는 MCP 서버
├── client.py          # 서버를 자동 실행하고 MCP 기능을 호출하는 클라이언트
├── requirements.txt   # FastMCP 버전 고정
├── pyproject.toml
├── run_demo.sh
└── data/
    └── notes.json     # 메모 저장 파일
```

## 2. WSL Ubuntu 준비

Windows PowerShell을 관리자 권한으로 열고 WSL이 없다면 실행합니다.

```powershell
wsl --install
```

재부팅 후 Ubuntu 터미널을 열고 WSL 버전을 확인합니다.

```powershell
wsl --list --verbose
```

`VERSION`이 `2`인지 확인합니다.

## 3. Ubuntu 패키지 설치

WSL Ubuntu 터미널에서 실행합니다.

```bash
sudo apt update
sudo apt install -y python3 python3-venv python3-pip
python3 --version
```

FastMCP 3.4.4는 Python 3.10 이상이 필요합니다.

## 4. 프로젝트 폴더로 이동

압축 파일을 WSL 홈 폴더에 풀었다고 가정합니다.

```bash
cd ~/fastmcp_wsl_beginner
```

Windows 다운로드 폴더에 압축을 풀었다면 예시는 다음과 같습니다.

```bash
cd /mnt/c/Users/<Windows사용자명>/Downloads/fastmcp_wsl_beginner
```

학습 프로젝트는 가능하면 `/mnt/c/...`보다 WSL 홈인 `~/...` 아래에 두는 것을
권장합니다.

## 5. Python 가상환경 생성

```bash
python3 -m venv .venv
source .venv/bin/activate
```

정상적으로 활성화되면 프롬프트 앞에 `(.venv)`가 표시됩니다.

## 6. FastMCP 설치

```bash
python -m pip install --upgrade pip
python -m pip install -r requirements.txt
fastmcp version
```

## 7. 실습 실행

서버를 별도로 먼저 실행하지 않고 클라이언트만 실행합니다.

```bash
python client.py
```

또는:

```bash
./run_demo.sh
```

클라이언트가 `server.py`를 자식 프로세스로 자동 실행합니다.

## 8. 예상 흐름

```text
client.py 실행
  -> server.py subprocess 시작
  -> MCP initialize 및 ping
  -> tools/list, resources/list, prompts/list
  -> add / greet / add_note / search_notes 호출
  -> notes://all 읽기
  -> study_review prompt 요청
  -> 연결 종료
  -> server.py 프로세스 종료
```

## 9. 저장 결과 확인

```bash
cat data/notes.json
```

`client.py`를 실행할 때마다 새 메모가 하나씩 추가됩니다. 처음부터 다시
실습하려면 다음 명령으로 파일을 초기화합니다.

```bash
printf '[]\n' > data/notes.json
```

## 10. MCP Inspector 선택 실습

Node.js와 npm이 설치되어 있다면 다음 명령으로 서버를 점검할 수 있습니다.

```bash
npx @modelcontextprotocol/inspector \
  .venv/bin/python \
  server.py
```

브라우저에서 Tools, Resources, Prompts 탭을 열어 직접 호출합니다.

## 11. 자주 발생하는 오류

### `ModuleNotFoundError: No module named 'fastmcp'`

가상환경을 다시 활성화하고 설치합니다.

```bash
source .venv/bin/activate
python -m pip install -r requirements.txt
```

### `python3 -m venv` 실패

```bash
sudo apt install -y python3-venv
```

### 서버를 실행했는데 터미널이 멈춘 것처럼 보임

`python server.py`를 직접 실행하면 stdio 요청을 기다리므로 정상입니다.
`Ctrl+C`로 종료한 후 `python client.py`를 실행하세요.

### stdout에 `print()` 로그를 추가했더니 연결 오류 발생

stdio 서버의 stdout은 MCP JSON-RPC 메시지 전용입니다. 서버 디버그 출력은
stderr 또는 파일 로깅을 사용해야 합니다.
