#!/usr/bin/env bash
set -euo pipefail

# 이 스크립트는 반드시 프로젝트의 가상환경을 활성화한 뒤 실행하세요.
python client.py
