"""초급자용 FastMCP 서버 예제.

이 서버는 다음 MCP 구성요소를 제공합니다.
1. Tools: add, greet, add_note, search_notes
2. Resource: notes://all
3. Prompt: study_review

실행 방식은 stdio입니다. 일반적으로 client.py가 이 파일을 자식 프로세스로
자동 실행하므로 서버 터미널을 별도로 열 필요가 없습니다.
"""

from __future__ import annotations

import json
from datetime import datetime
from pathlib import Path
from typing import Any

from fastmcp import FastMCP


# -----------------------------------------------------------------------------
# 1. FastMCP 서버 객체 생성
# -----------------------------------------------------------------------------
# 이 이름은 클라이언트가 서버 정보를 확인할 때 사용됩니다.
mcp = FastMCP("WSL Beginner MCP Server")


# -----------------------------------------------------------------------------
# 2. 메모 데이터 파일 준비
# -----------------------------------------------------------------------------
BASE_DIR = Path(__file__).resolve().parent
DATA_FILE = BASE_DIR / "data" / "notes.json"


def ensure_data_file() -> None:
    """data/notes.json 파일이 없으면 빈 배열로 생성합니다."""
    DATA_FILE.parent.mkdir(parents=True, exist_ok=True)
    if not DATA_FILE.exists():
        DATA_FILE.write_text("[]\n", encoding="utf-8")


def load_notes() -> list[dict[str, Any]]:
    """JSON 파일에서 메모 목록을 읽습니다."""
    ensure_data_file()

    try:
        raw_text = DATA_FILE.read_text(encoding="utf-8")
        notes = json.loads(raw_text)
    except json.JSONDecodeError as exc:
        raise ValueError("notes.json 파일의 JSON 형식이 올바르지 않습니다.") from exc

    if not isinstance(notes, list):
        raise ValueError("notes.json의 최상위 데이터는 배열이어야 합니다.")

    return notes


def save_notes(notes: list[dict[str, Any]]) -> None:
    """메모 목록을 UTF-8 JSON 파일로 저장합니다."""
    ensure_data_file()
    DATA_FILE.write_text(
        json.dumps(notes, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )


# -----------------------------------------------------------------------------
# 3. Tool 등록
# -----------------------------------------------------------------------------
# Tool은 클라이언트가 '실행'할 수 있는 함수입니다.


@mcp.tool
def add(a: int, b: int) -> int:
    """두 정수를 더한 값을 반환합니다."""
    return a + b


@mcp.tool
def greet(name: str) -> str:
    """입력한 이름으로 환영 인사를 만듭니다."""
    clean_name = name.strip()
    if not clean_name:
        raise ValueError("name은 빈 문자열일 수 없습니다.")
    return f"안녕하세요, {clean_name}님! FastMCP 실습에 오신 것을 환영합니다."


@mcp.tool
def add_note(title: str, content: str) -> dict[str, Any]:
    """새 학습 메모를 notes.json에 저장합니다."""
    clean_title = title.strip()
    clean_content = content.strip()

    if not clean_title:
        raise ValueError("title은 비어 있을 수 없습니다.")
    if not clean_content:
        raise ValueError("content는 비어 있을 수 없습니다.")

    notes = load_notes()

    # 삭제 기능이 없는 초급 예제이므로 현재 개수 + 1로 ID를 생성합니다.
    note = {
        "id": len(notes) + 1,
        "title": clean_title,
        "content": clean_content,
        "created_at": datetime.now().astimezone().isoformat(timespec="seconds"),
    }

    notes.append(note)
    save_notes(notes)
    return note


@mcp.tool
def search_notes(keyword: str) -> list[dict[str, Any]]:
    """제목 또는 내용에 키워드가 포함된 메모를 검색합니다."""
    clean_keyword = keyword.strip().lower()
    if not clean_keyword:
        raise ValueError("keyword는 비어 있을 수 없습니다.")

    notes = load_notes()
    return [
        note
        for note in notes
        if clean_keyword in str(note.get("title", "")).lower()
        or clean_keyword in str(note.get("content", "")).lower()
    ]


# -----------------------------------------------------------------------------
# 4. Resource 등록
# -----------------------------------------------------------------------------
# Resource는 클라이언트가 '읽는' 데이터입니다.


@mcp.resource("notes://all", mime_type="application/json")
def get_all_notes() -> str:
    """저장된 전체 메모를 JSON 문자열로 제공합니다."""
    return json.dumps(load_notes(), ensure_ascii=False, indent=2)


# -----------------------------------------------------------------------------
# 5. Prompt 등록
# -----------------------------------------------------------------------------
# Prompt는 LLM에게 전달할 재사용 가능한 메시지 템플릿입니다.


@mcp.prompt
def study_review(topic: str) -> str:
    """특정 주제를 복습하기 위한 질문 템플릿을 생성합니다."""
    clean_topic = topic.strip()
    if not clean_topic:
        raise ValueError("topic은 비어 있을 수 없습니다.")

    return (
        f"'{clean_topic}' 주제를 초급자 수준으로 복습해 주세요.\n"
        "다음 순서로 답변해 주세요.\n"
        "1. 핵심 개념 3개\n"
        "2. 쉬운 비유\n"
        "3. 짧은 실습 예제\n"
        "4. 확인 문제 3개"
    )


# -----------------------------------------------------------------------------
# 6. 서버 실행
# -----------------------------------------------------------------------------
# 인자를 지정하지 않으면 기본 transport는 stdio입니다.
# stdio 서버는 stdout을 MCP 메시지용으로 사용하므로 일반 print() 로그를
# 함부로 출력하지 않는 것이 중요합니다.
if __name__ == "__main__":
    mcp.run()
