"""초급자용 FastMCP 클라이언트 예제.

실행하면 다음 순서로 동작합니다.
1. server.py를 자식 프로세스로 자동 실행
2. MCP 서버 연결 확인
3. Tool / Resource / Prompt 목록 조회
4. Tool 호출
5. Resource 읽기
6. Prompt 가져오기
7. 연결 종료와 함께 서버 프로세스 종료
"""

from __future__ import annotations

import asyncio
import json
import sys
from pathlib import Path
from typing import Any

from fastmcp import Client
from fastmcp.client.transports import StdioTransport


BASE_DIR = Path(__file__).resolve().parent
SERVER_FILE = BASE_DIR / "server.py"

# 각 설명을 읽을 수 있도록 다음 동작 전에 기다리는 시간입니다.
# 실습을 빠르게 진행하려면 1.0처럼 줄이고, 기다리지 않으려면 0으로 바꾸세요.
STEP_DELAY_SECONDS = 3.0


def print_title(text: str) -> None:
    """출력 구역을 보기 쉽게 구분합니다."""
    print("\n" + "=" * 70)
    print(text)
    print("=" * 70)


def pretty(value: Any) -> str:
    """dict/list를 읽기 쉬운 JSON 형태로 출력합니다."""
    if isinstance(value, (dict, list)):
        return json.dumps(value, ensure_ascii=False, indent=2, default=str)
    return str(value)


async def explain_step(title: str, explanation: str) -> None:
    """현재 학습 내용을 설명하고, 읽을 시간을 준 뒤 다음 단계로 이동합니다."""
    print_title(title)
    print("[학습 포인트]")
    print(explanation)

    if STEP_DELAY_SECONDS > 0:
        print(f"\n{STEP_DELAY_SECONDS:g}초 후 실습을 계속합니다...")
        # time.sleep()과 달리 asyncio.sleep()은 비동기 작업 전체를 막지 않습니다.
        await asyncio.sleep(STEP_DELAY_SECONDS)


async def main() -> None:
    # 현재 client.py를 실행한 Python을 그대로 사용해 server.py를 실행합니다.
    # 따라서 가상환경 안에서 `python client.py`를 실행하면 서버도 같은
    # 가상환경의 FastMCP 패키지를 사용합니다.
    transport = StdioTransport(
        command=sys.executable,
        args=[str(SERVER_FILE)],
        cwd=str(BASE_DIR),
    )

    client = Client(transport)

    await explain_step(
        "0. FastMCP 클라이언트 시작",
        "MCP는 클라이언트가 서버의 기능과 데이터를 표준 방식으로 사용하는 "
        "프로토콜입니다.\n"
        "이 예제에서는 client.py가 MCP 클라이언트이고 server.py가 MCP 서버입니다.",
    )
    print(f"클라이언트 Python: {sys.executable}")
    print(f"실행할 서버 파일: {SERVER_FILE}")
    print("연결 방식: stdio (표준 입력과 표준 출력)")

    try:
        # async with 블록에 들어가면 서버 프로세스가 시작되고 MCP 연결이 열립니다.
        async with client:
            await explain_step(
                "1. 서버 연결 확인",
                "async with client에 들어오면서 server.py가 자식 프로세스로 실행되고 "
                "MCP 연결이 열렸습니다.\n"
                "ping은 서버가 요청을 받고 응답할 수 있는지 확인하는 가장 간단한 "
                "통신 테스트입니다.",
            )
            await client.ping()
            print("서버가 정상적으로 응답했습니다.")

            await explain_step(
                "2. 서버가 제공하는 구성요소 목록",
                "MCP 클라이언트는 서버 코드를 미리 몰라도 서버가 제공하는 기능을 "
                "목록으로 조회할 수 있습니다.\n"
                "Tool은 실행할 함수, Resource는 읽을 데이터, Prompt는 재사용할 "
                "메시지 양식입니다.",
            )

            tools = await client.list_tools()
            print("[Tools]")
            for tool in tools:
                print(f"- {tool.name}: {tool.description or '설명 없음'}")

            resources = await client.list_resources()
            print("\n[Resources]")
            for resource in resources:
                print(f"- {resource.uri}: {resource.description or resource.name}")

            prompts = await client.list_prompts()
            print("\n[Prompts]")
            for prompt in prompts:
                print(f"- {prompt.name}: {prompt.description or '설명 없음'}")

            await explain_step(
                "3. Tool 호출: add",
                "Tool 호출은 클라이언트가 서버에 함수 이름과 인자를 보내 실행을 "
                "요청하는 과정입니다.\n"
                '여기서는 "add" Tool에 정수 a=7, b=5를 전달합니다.',
            )
            add_result = await client.call_tool("add", {"a": 7, "b": 5})
            print(f"7 + 5 = {pretty(add_result.data)}")

            await explain_step(
                "4. Tool 호출: greet",
                "같은 call_tool() 메서드로 다른 서버 기능도 실행할 수 있습니다.\n"
                '서버는 "name" 인자를 받아 인사말을 만들고 그 결과를 클라이언트에 '
                "돌려줍니다.",
            )
            greet_result = await client.call_tool("greet", {"name": "MCP 학습자"})
            print(pretty(greet_result.data))

            await explain_step(
                "5. Tool 호출: add_note",
                "Tool은 계산뿐 아니라 파일 저장 같은 작업도 수행할 수 있습니다.\n"
                "이 호출은 메모를 data/notes.json에 실제로 추가하므로 client.py를 "
                "실행할 때마다 메모가 하나씩 늘어납니다.",
            )
            note_result = await client.call_tool(
                "add_note",
                {
                    "title": "FastMCP 첫 실습",
                    "content": "WSL에서 stdio 방식으로 client와 server를 연결했다.",
                },
            )
            print("저장된 메모:")
            print(pretty(note_result.data))

            await explain_step(
                "6. Tool 호출: search_notes",
                "이번 Tool은 서버에 저장된 메모 중 제목이나 내용에 검색어가 포함된 "
                "항목을 찾습니다.\n"
                "클라이언트는 데이터의 저장 방식을 몰라도 서버가 공개한 Tool을 통해 "
                "검색할 수 있습니다.",
            )
            search_result = await client.call_tool(
                "search_notes",
                {"keyword": "stdio"},
            )
            print("검색 결과:")
            print(pretty(search_result.data))

            await explain_step(
                "7. Resource 읽기: notes://all",
                "Resource는 실행 명령이 아니라 서버가 공개한 데이터를 읽는 "
                "인터페이스입니다.\n"
                "notes://all은 파일 경로가 아닌 MCP Resource URI이며, 저장된 전체 "
                "메모를 JSON 형식으로 제공합니다.",
            )
            resource_contents = await client.read_resource("notes://all")
            for item in resource_contents:
                if hasattr(item, "text"):
                    print(item.text)
                elif hasattr(item, "blob"):
                    print(f"바이너리 데이터 {len(item.blob)} bytes")

            await explain_step(
                "8. Prompt 가져오기: study_review",
                "Prompt는 LLM에 보낼 지시문을 서버가 재사용 가능한 양식으로 제공하는 "
                "기능입니다.\n"
                "topic 인자를 넣으면 서버가 학습 주제에 맞춘 복습용 메시지를 "
                "생성합니다. 여기서는 메시지를 가져오기만 하며 LLM을 직접 호출하지는 "
                "않습니다.",
            )
            prompt_result = await client.get_prompt(
                "study_review",
                {"topic": "MCP Server와 Client"},
            )
            for index, message in enumerate(prompt_result.messages, start=1):
                content = (
                    message.content.text
                    if hasattr(message.content, "text")
                    else message.content
                )
                print(f"메시지 {index} / role={message.role}")
                print(content)

        # async with 블록을 벗어나면 연결과 서버 프로세스가 정리됩니다.
        await explain_step(
            "9. 실습 완료",
            "async with 블록을 벗어나면 MCP 연결이 닫히고 client.py가 시작했던 "
            "server.py 프로세스도 자동으로 종료됩니다.\n"
            "이 실습으로 연결, 기능 탐색, Tool 호출, Resource 읽기, Prompt 가져오기의 "
            "전체 흐름을 확인했습니다.",
        )
        print("MCP 연결이 종료되었고 서버 프로세스도 정리되었습니다.")

    except FileNotFoundError:
        print("오류: server.py 또는 Python 실행 파일을 찾지 못했습니다.")
        raise SystemExit(1)
    except Exception as exc:
        print_title("실행 중 오류 발생")
        print(f"오류 종류: {type(exc).__name__}")
        print(f"오류 내용: {exc}")
        print("가상환경 활성화와 FastMCP 설치 여부를 확인하세요.")
        raise SystemExit(1) from exc


if __name__ == "__main__":
    asyncio.run(main())
